<?php return array (
  'livewireComponents' => 
  array (
    'App\\Filament\\Resources\\CalculatorOption\\Pages\\CreateCalculatorOption' => 'App\\Filament\\Resources\\CalculatorOption\\Pages\\CreateCalculatorOption',
    'App\\Filament\\Resources\\CalculatorOption\\Pages\\EditCalculatorOption' => 'App\\Filament\\Resources\\CalculatorOption\\Pages\\EditCalculatorOption',
    'App\\Filament\\Resources\\CalculatorOption\\Pages\\ListCalculatorOptions' => 'App\\Filament\\Resources\\CalculatorOption\\Pages\\ListCalculatorOptions',
    'App\\Filament\\Resources\\ContactRequest\\Pages\\CreateContactRequest' => 'App\\Filament\\Resources\\ContactRequest\\Pages\\CreateContactRequest',
    'App\\Filament\\Resources\\ContactRequest\\Pages\\EditContactRequest' => 'App\\Filament\\Resources\\ContactRequest\\Pages\\EditContactRequest',
    'App\\Filament\\Resources\\ContactRequest\\Pages\\ListContactRequests' => 'App\\Filament\\Resources\\ContactRequest\\Pages\\ListContactRequests',
    'App\\Filament\\Resources\\EstimateRequest\\Pages\\CreateEstimateRequest' => 'App\\Filament\\Resources\\EstimateRequest\\Pages\\CreateEstimateRequest',
    'App\\Filament\\Resources\\EstimateRequest\\Pages\\EditEstimateRequest' => 'App\\Filament\\Resources\\EstimateRequest\\Pages\\EditEstimateRequest',
    'App\\Filament\\Resources\\EstimateRequest\\Pages\\ListEstimateRequests' => 'App\\Filament\\Resources\\EstimateRequest\\Pages\\ListEstimateRequests',
    'App\\Filament\\Resources\\EstimateRequest\\Pages\\ViewEstimateRequest' => 'App\\Filament\\Resources\\EstimateRequest\\Pages\\ViewEstimateRequest',
    'App\\Filament\\Resources\\PageSection\\Pages\\CreatePageSection' => 'App\\Filament\\Resources\\PageSection\\Pages\\CreatePageSection',
    'App\\Filament\\Resources\\PageSection\\Pages\\EditPageSection' => 'App\\Filament\\Resources\\PageSection\\Pages\\EditPageSection',
    'App\\Filament\\Resources\\PageSection\\Pages\\ListPageSections' => 'App\\Filament\\Resources\\PageSection\\Pages\\ListPageSections',
    'App\\Filament\\Resources\\ProjectCategory\\Pages\\CreateProjectCategory' => 'App\\Filament\\Resources\\ProjectCategory\\Pages\\CreateProjectCategory',
    'App\\Filament\\Resources\\ProjectCategory\\Pages\\EditProjectCategory' => 'App\\Filament\\Resources\\ProjectCategory\\Pages\\EditProjectCategory',
    'App\\Filament\\Resources\\ProjectCategory\\Pages\\ListProjectCategories' => 'App\\Filament\\Resources\\ProjectCategory\\Pages\\ListProjectCategories',
    'App\\Filament\\Resources\\Project\\Pages\\CreateProject' => 'App\\Filament\\Resources\\Project\\Pages\\CreateProject',
    'App\\Filament\\Resources\\Project\\Pages\\EditProject' => 'App\\Filament\\Resources\\Project\\Pages\\EditProject',
    'App\\Filament\\Resources\\Project\\Pages\\ListProjects' => 'App\\Filament\\Resources\\Project\\Pages\\ListProjects',
    'App\\Filament\\Resources\\Service\\Pages\\CreateService' => 'App\\Filament\\Resources\\Service\\Pages\\CreateService',
    'App\\Filament\\Resources\\Service\\Pages\\EditService' => 'App\\Filament\\Resources\\Service\\Pages\\EditService',
    'App\\Filament\\Resources\\Service\\Pages\\ListServices' => 'App\\Filament\\Resources\\Service\\Pages\\ListServices',
    'App\\Filament\\Resources\\Slider\\Pages\\CreateSlider' => 'App\\Filament\\Resources\\Slider\\Pages\\CreateSlider',
    'App\\Filament\\Resources\\Slider\\Pages\\EditSlider' => 'App\\Filament\\Resources\\Slider\\Pages\\EditSlider',
    'App\\Filament\\Resources\\Slider\\Pages\\ListSliders' => 'App\\Filament\\Resources\\Slider\\Pages\\ListSliders',
    'App\\Filament\\Pages\\SiteSettings' => 'App\\Filament\\Pages\\SiteSettings',
    'Filament\\Pages\\Dashboard' => 'Filament\\Pages\\Dashboard',
    'App\\Filament\\Widgets\\StatsOverview' => 'App\\Filament\\Widgets\\StatsOverview',
    'App\\Filament\\Widgets\\VisitsChart' => 'App\\Filament\\Widgets\\VisitsChart',
    'Filament\\Widgets\\AccountWidget' => 'Filament\\Widgets\\AccountWidget',
    'Filament\\Widgets\\FilamentInfoWidget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'Filament\\Livewire\\DatabaseNotifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'Filament\\Auth\\Pages\\EditProfile' => 'Filament\\Auth\\Pages\\EditProfile',
    'Filament\\Livewire\\GlobalSearch' => 'Filament\\Livewire\\GlobalSearch',
    'Filament\\Livewire\\Notifications' => 'Filament\\Livewire\\Notifications',
    'Filament\\Livewire\\Sidebar' => 'Filament\\Livewire\\Sidebar',
    'Filament\\Livewire\\SimpleUserMenu' => 'Filament\\Livewire\\SimpleUserMenu',
    'Filament\\Livewire\\Topbar' => 'Filament\\Livewire\\Topbar',
    'Filament\\Auth\\Pages\\Login' => 'Filament\\Auth\\Pages\\Login',
    'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ListRoles' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ListRoles',
    'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\CreateRole' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\CreateRole',
    'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ViewRole' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ViewRole',
    'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\EditRole' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Pages\\SiteSettings.php' => 'App\\Filament\\Pages\\SiteSettings',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\wamp64\\www\\florascape\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\CalculatorOption\\CalculatorOptionResource.php' => 'App\\Filament\\Resources\\CalculatorOption\\CalculatorOptionResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\ContactRequest\\ContactRequestResource.php' => 'App\\Filament\\Resources\\ContactRequest\\ContactRequestResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\EstimateRequest\\EstimateRequestResource.php' => 'App\\Filament\\Resources\\EstimateRequest\\EstimateRequestResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\PageSection\\PageSectionResource.php' => 'App\\Filament\\Resources\\PageSection\\PageSectionResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\ProjectCategory\\ProjectCategoryResource.php' => 'App\\Filament\\Resources\\ProjectCategory\\ProjectCategoryResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\Project\\ProjectResource.php' => 'App\\Filament\\Resources\\Project\\ProjectResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\Service\\ServiceResource.php' => 'App\\Filament\\Resources\\Service\\ServiceResource',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Resources\\Slider\\SliderResource.php' => 'App\\Filament\\Resources\\Slider\\SliderResource',
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\RoleResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\wamp64\\www\\florascape\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    'C:\\wamp64\\www\\florascape\\app\\Filament\\Widgets\\VisitsChart.php' => 'App\\Filament\\Widgets\\VisitsChart',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\wamp64\\www\\florascape\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);