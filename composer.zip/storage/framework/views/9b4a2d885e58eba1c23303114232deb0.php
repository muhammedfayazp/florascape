<section class="relative w-full h-[500px]">


    
<!-- Swiper container -->
<div style="width: 100%; height: 60vh; position: relative;" class="swiper mySwiper">
    <div class="swiper-wrapper">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
        <div class="swiper-slide" style="
        background-image: url('<?php echo e($slide['image']); ?>');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        width: 100%;
        height: 100%;
        "></div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
    <!-- Bottom right half container -->
    <div style="position: absolute;bottom: 0;left: 50%;width: 50%;height: 48px;background: rgba(0, 0, 0, 0.6);
        display: flex;align-items: center;padding: 0 16px;color: #fff;font-size: 16px;font-weight: 600;
        z-index: 30;box-sizing: border-box;">
        <!-- Pagination -->
        <div class="swiper-pagination" style="text-align: left;"></div>
        <!-- Navigation buttons pushed to far right -->
        <div style="display: flex; gap: 12px; margin-left: auto;">
            <button class="swiper-button-prev-custom" style="background: #fff;width: 36px;height: 36px;
                border: none; display: flex; align-items: center;justify-content: center; cursor: pointer;"
            >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <polyline points="15 18 9 12 15 6" />
            </svg>
            </button>
            <button class="swiper-button-next-custom" style="background: #fff;width: 36px;height: 36px;
                border: none;display: flex;align-items: center;justify-content: center;cursor: pointer;"
            >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                <polyline points="9 18 15 12 9 6" />
            </svg>
            </button>
        </div>
    </div>
</div>

    <div class="swiper mySwiper h-full w-full">
        <div class="swiper-wrapper">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <div class="swiper-slide relative bg-cover bg-center" style="background-image: url('<?php echo e($slide['image']); ?>');">
                    <div class="absolute inset-0 bg-black/40 z-10"></div>
                    <div class="relative z-20 flex items-center h-full px-6 md:px-20">
                        <div class="max-w-2xl text-white">
                            <h1 class="text-2xl md:text-4xl font-bold leading-tight mb-4"><?php echo e($slide['title']); ?></h1>
                            <p class="text-sm md:text-lg mb-6"><?php echo e($slide['description']); ?></p>
                            <a href="#" class="inline-block bg-green-600 hover:bg-green-700 transition px-5 py-3 text-white font-semibold rounded-md">
                                Get A Quote
                            </a>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <!-- Arrows -->
        <div class="swiper-button-next text-white"></div>
        <div class="swiper-button-prev text-white"></div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    
    <!-- Include Swiper JS -->
    

    <script>
    new Swiper(".mySwiper", {
        loop: true,
        slidesPerView: 1,
        pagination: {
        el: ".swiper-pagination",
        type: "custom",
        renderCustom: function (swiper, current, total) {
            // current and total are 1-based slide indexes including loop duplicates
            // To show real slide count ignoring loop duplicates, adjust total if needed.
            // Assuming 3 real slides here, you can hardcode or calculate total slides.
            const realTotal = 3; // replace with your actual slide count if dynamic
            // Calculate real current slide number (1 to realTotal)
            let realCurrent = ((current - 1) % realTotal) + 1;

            return `${realCurrent}/${realTotal}`;
        },
        },
        navigation: {
        nextEl: ".swiper-button-next-custom",
        prevEl: ".swiper-button-prev-custom",
        },
        autoplay: {
        delay: 4000,
        disableOnInteraction: false,
        },
        speed: 600,
    });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\florascape\resources\views\livewire\carousel-component.blade.php ENDPATH**/ ?>