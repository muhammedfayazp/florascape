<div <?php echo e($attributes->class(['fi-btn-group'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\wamp64\www\florascape\vendor\filament\support\resources\views\components\button\group.blade.php ENDPATH**/ ?>