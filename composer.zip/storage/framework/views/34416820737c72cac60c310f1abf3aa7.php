<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH C:\wamp64\www\florascape\vendor\filament\support\resources\views\components\loading-indicator.blade.php ENDPATH**/ ?>