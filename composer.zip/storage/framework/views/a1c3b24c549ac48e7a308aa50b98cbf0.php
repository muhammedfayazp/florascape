<p
    <?php echo e($attributes->class(['fi-modal-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\wamp64\www\florascape\vendor\filament\support\resources\views\components\modal\description.blade.php ENDPATH**/ ?>