<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\wamp64\www\florascape\vendor\filament\widgets\resources\views\components\widget.blade.php ENDPATH**/ ?>