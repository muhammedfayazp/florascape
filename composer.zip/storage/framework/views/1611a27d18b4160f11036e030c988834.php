<p
    <?php echo e($attributes->class(['fi-section-header-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\wamp64\www\florascape\vendor\filament\support\resources\views\components\section\description.blade.php ENDPATH**/ ?>