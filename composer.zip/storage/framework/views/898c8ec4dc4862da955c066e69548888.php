<section class="relative w-full h-[500px]">

    <!-- Swiper container -->
    <div style="width: 100%; height: 60vh; position: relative;" class="swiper mySwiper">
        <div class="swiper-wrapper">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                <?php
                    $imageUrl = Str::startsWith($slide['image'], 'http')
                        ? $slide['image']
                        : \Illuminate\Support\Facades\Storage::url($slide['image']);
                ?>

                <div class="swiper-slide relative" style="
                    background-image: url('<?php echo $imageUrl; ?>');
                    background-position: center;
                    background-repeat: no-repeat;
                    background-size: cover;
                    width: 100%;
                    height: 100%;
                ">
                    <div class="absolute inset-0 bg-black/40 flex flex-col justify-center items-start p-8 text-white">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($slide['title'])): ?>
                            <h2 class="text-3xl font-bold"><?php echo e($slide['title']); ?></h2>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($slide['description'])): ?>
                            <p class="mt-2 max-w-lg"><?php echo e($slide['description']); ?></p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($slide['redirect_link'])): ?>
                            <a href="<?php echo e($slide['redirect_link']); ?>" 
                               class="mt-4 inline-block bg-white text-black px-4 py-2 rounded-lg font-semibold hover:bg-gray-200">
                                Learn More
                            </a>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <!-- Bottom right container with pagination & nav -->
        <div style="position: absolute;bottom: 0;left: 50%;width: 50%;height: 48px;background: rgba(0, 0, 0, 0.6);
            display: flex;align-items: center;padding: 0 16px;color: #fff;font-size: 16px;font-weight: 600;
            z-index: 30;box-sizing: border-box;">
            <!-- Pagination -->
            <div class="swiper-pagination" style="text-align: left;"></div>

            <!-- Navigation -->
            <div style="display: flex; gap: 12px; margin-left: auto;">
                <button class="swiper-button-prev-custom" style="background: #fff;width: 36px;height: 36px;
                    border: none; display: flex; align-items: center;justify-content: center; cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                        <polyline points="15 18 9 12 15 6" />
                    </svg>
                </button>
                <button class="swiper-button-next-custom" style="background: #fff;width: 36px;height: 36px;
                    border: none;display: flex;align-items: center;justify-content: center;cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24">
                        <polyline points="9 18 15 12 9 6" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
        new Swiper(".mySwiper", {
            loop: true,
            slidesPerView: 1,
            pagination: {
                el: ".swiper-pagination",
                type: "custom",
                renderCustom: function (swiper, current, total) {
                    const realTotal = <?php echo e(count($slides)); ?>;
                    let realCurrent = ((current - 1) % realTotal) + 1;
                    return `${realCurrent}/${realTotal}`;
                },
            },
            navigation: {
                nextEl: ".swiper-button-next-custom",
                prevEl: ".swiper-button-prev-custom",
            },
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            speed: 600,
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\florascape\resources\views\livewire\hero-slider.blade.php ENDPATH**/ ?>