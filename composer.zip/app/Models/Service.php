<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'icon', 'description', 'features', 'sort_order', 'type'];

    protected $casts = [
        'features' => 'array',
    ];
}
